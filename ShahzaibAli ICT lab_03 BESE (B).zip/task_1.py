name = str(input("Enter your name :"))
age = int(input("Enter your age :"))
height = tuple(input("Enter your height :"))
is_student = bool(input("Enter your is_student :"))

print("your name is :" ,name)
print("your age is :",age)
print("your height is :",height)
print("your staus is :",is_student)

